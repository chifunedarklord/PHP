<?php
require 'config.php';
require 'functions.php';


$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM categories WHERE id=?");
$stmt->execute([$id]);
$data = $stmt->fetch();
if (!$data) die('Not found');


$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$data = array_merge($data, $_POST);


if (strlen(trim($data['name'])) < 3)
$errors['name'] = 'Name quá ngắn';


$stmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug=? AND id<>?");
$stmt->execute([$data['slug'],$id]);
if ($stmt->fetchColumn() > 0)
$errors['slug'] = 'Slug đã tồn tại';


if (!$errors) {
$stmt = $pdo->prepare("UPDATE categories SET name=?,slug=?,description=?,status=? WHERE id=?");
$stmt->execute([
$data['name'],$data['slug'],$data['description'],$data['status'],$id
]);
set_flash('Cập nhật thành công');
header('Location: index.php'); exit;
}
}
?>
<!doctype html>
<html><body>
<h2>Sửa danh mục</h2>
<form method="post">
Name: <input name="name" value="<?= e($data['name']) ?>">
<span style="color:red;"><?= $errors['name'] ?? '' ?></span><br>
Slug: <input name="slug" value="<?= e($data['slug']) ?>">
<span style="color:red;"><?= $errors['slug'] ?? '' ?></span><br>
<textarea name="description"><?= e($data['description']) ?></textarea><br>
<select name="status">
<option value="1" <?= $data['status']==1?'selected':'' ?>>Active</option>
<option value="0" <?= $data['status']==0?'selected':'' ?>>Inactive</option>
</select><br>
<button>Update</button>
<a href="index.php">Back</a>
</form>
</body></html>