<?php
require 'config.php';
require 'functions.php';


$errors = [];
$data = ['name'=>'','slug'=>'','description'=>'','status'=>1];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$data = $_POST;


if (strlen(trim($data['name'])) < 3 || strlen($data['name']) > 100)
$errors['name'] = 'Name 3–100 ký tự';


if (!preg_match('/^[a-z0-9-]+$/', $data['slug']))
$errors['slug'] = 'Slug chỉ gồm a-z 0-9 -';


$stmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE slug=?");
$stmt->execute([$data['slug']]);
if ($stmt->fetchColumn() > 0)
$errors['slug'] = 'Slug đã tồn tại';


$data['status'] = $data['status'] == 1 ? 1 : 0;


if (!$errors) {
$stmt = $pdo->prepare("INSERT INTO categories(name,slug,description,status) VALUES (?,?,?,?)");
$stmt->execute([
$data['name'], $data['slug'], $data['description'], $data['status']
]);
set_flash('Thêm mới thành công');
header('Location: index.php'); exit;
}
}
?>
<!doctype html>
<html><body>
<h2>Thêm danh mục</h2>
<form method="post">
Name: <input name="name" value="<?= e($data['name']) ?>">
<span style="color:red;"><?= $errors['name'] ?? '' ?></span><br>
Slug: <input name="slug" value="<?= e($data['slug']) ?>">
<span style="color:red;"><?= $errors['slug'] ?? '' ?></span><br>
Description:<br>
<textarea name="description"><?= e($data['description']) ?></textarea><br>
Status:
<select name="status">
<option value="1" <?= $data['status']==1?'selected':'' ?>>Active</option>
<option value="0" <?= $data['status']==0?'selected':'' ?>>Inactive</option>
</select><br>
<button>Save</button>
<a href="index.php">Back</a>
</form>
</body></html>