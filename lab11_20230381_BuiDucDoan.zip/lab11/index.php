<?php
require 'config.php';
require 'functions.php';


$keyword = $_GET['q'] ?? '';
$sql = "SELECT * FROM categories WHERE 1";
$params = [];


if ($keyword !== '') {
$sql .= " AND (name LIKE :kw OR slug LIKE :kw)";
$params[':kw'] = "%$keyword%";
}


$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Categories</title></head>
<body>
<h2>Danh mục</h2>


<?php if ($msg = get_flash()): ?>
<p style="color:green;"><?= e($msg) ?></p>
<?php endif; ?>


<form method="get">
<input name="q" value="<?= e($keyword) ?>" placeholder="Search name / slug">
<button>Tìm</button>
<a href="create.php">Thêm mới</a>
</form>


<table border="1" cellpadding="5" cellspacing="0">
<tr>
<th>ID</th><th>Name</th><th>Slug</th><th>Status</th><th>Actions</th>
</tr>
<?php foreach ($rows as $r): ?>
<tr>
<td><?= e($r['id']) ?></td>
<td><?= e($r['name']) ?></td>
<td><?= e($r['slug']) ?></td>
<td><?= $r['status'] ? 'Active' : 'Inactive' ?></td>
<td>
<a href="edit.php?id=<?= $r['id'] ?>">Edit</a> |
<a onclick="return confirm('Xóa danh mục?')" href="delete.php?id=<?= $r['id'] ?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</table>
</body>
</html>