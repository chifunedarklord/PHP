<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài 2 - Máy tính mini</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; }
        .form-group {
            margin: 15px 0;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="number"], select {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #218838;
        }
        .result {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            font-size: 18px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="GET" action="">
            <div class="form-group">
                <label for="a">Số thứ nhất (a):</label>
                <input type="number" id="a" name="a" step="0.01" 
                       value="<?php echo isset($_GET['a']) ? htmlspecialchars($_GET['a']) : '0'; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="b">Số thứ hai (b):</label>
                <input type="number" id="b" name="b" step="0.01" 
                       value="<?php echo isset($_GET['b']) ? htmlspecialchars($_GET['b']) : '0'; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="op">Phép toán:</label>
                <select id="op" name="op" required>
                    <option value="add" <?php echo (isset($_GET['op']) && $_GET['op'] == 'add') ? 'selected' : ''; ?>>Cộng (+)</option>
                    <option value="sub" <?php echo (isset($_GET['op']) && $_GET['op'] == 'sub') ? 'selected' : ''; ?>>Trừ (-)</option>
                    <option value="mul" <?php echo (isset($_GET['op']) && $_GET['op'] == 'mul') ? 'selected' : ''; ?>>Nhân (×)</option>
                    <option value="div" <?php echo (isset($_GET['op']) && $_GET['op'] == 'div') ? 'selected' : ''; ?>>Chia (÷)</option>
                </select>
            </div>
            
            <button type="submit">Tính toán</button>
        </form>

        <?php
        if (isset($_GET['a']) && isset($_GET['b']) && isset($_GET['op'])) {
            $a = (float)$_GET["a"];
            $b = (float)$_GET["b"];
            $op = $_GET["op"];
            
            $result = null;
            $error = false;
            $symbol = "";
            
            switch ($op) {
                case "add":
                    $result = $a + $b;
                    $symbol = "+";
                    break;
                    
                case "sub":
                    $result = $a - $b;
                    $symbol = "-";
                    break;
                    
                case "mul":
                    $result = $a * $b;
                    $symbol = "×";
                    break;
                    
                case "div":
                    if ($b == 0) {
                        $error = true;
                        echo '<div class="result error"><strong>Lỗi:</strong> Không thể chia cho 0!</div>';
                    } else {
                        $result = $a / $b;
                        $symbol = "÷";
                    }
                    break;
                    
                default:
                    $error = true;
                    echo '<div class="result error"><strong>Lỗi:</strong> Phép toán không hợp lệ!</div>';
                    break;
            }
            
            if (!$error && $result !== null) {
                echo '<div class="result success">';
                echo '<strong>Kết quả:</strong><br>';
                echo number_format($a, 2) . ' ' . $symbol . ' ' . number_format($b, 2) . ' = <strong>' . number_format($result, 2) . '</strong>';
                echo '</div>';
            }
        }
        ?>

        <a href="index.php" class="back-link">← Quay lại trang chủ</a>
    </div>
</body>
</html>