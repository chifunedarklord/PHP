<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài 1 - Phân loại điểm</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; }
        .result {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            font-size: 18px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-group {
            margin: 20px 0;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="GET" action="">
            <div class="form-group">
                <label for="score">Nhập điểm (0-10):</label>
                <input type="number" id="score" name="score" step="0.1" min="0" max="10" 
                       value="<?php echo isset($_GET['score']) ? htmlspecialchars($_GET['score']) : ''; ?>" 
                       required>
            </div>
            <button type="submit">Xếp loại</button>
        </form>

        <?php
        if (isset($_GET["score"])) {
            $score = $_GET["score"];
            
            // Kiểm tra dữ liệu đầu vào
            if (!is_numeric($score)) {
                echo '<div class="result error">Lỗi: Điểm phải là một số!</div>';
            } else {
                $score = (float)$score;
                
                // Kiểm tra hợp lệ: 0 ≤ score ≤ 10
                if ($score < 0 || $score > 10) {
                    echo '<div class="result error">Lỗi: Điểm phải nằm trong khoảng từ 0 đến 10!</div>';
                } else {
                    // Phân loại điểm
                    if ($score >= 8.5) {
                        $rank = "Giỏi";
                        $color = "success";
                    } elseif ($score >= 7.0) {
                        $rank = "Khá";
                        $color = "success";
                    } elseif ($score >= 5.0) {
                        $rank = "Trung bình";
                        $color = "success";
                    } else {
                        $rank = "Yếu";
                        $color = "success";
                    }
                    
                    echo '<div class="result ' . $color . '">';
                    echo '<strong>Kết quả:</strong><br>';
                    echo 'Điểm: ' . number_format($score, 1) . ' – Xếp loại: <strong>' . $rank . '</strong>';
                    echo '</div>';
                }
            }
        }
        ?>

        <a href="index.php" class="back-link">← Quay lại trang chủ</a>
    </div>
</body>
</html>