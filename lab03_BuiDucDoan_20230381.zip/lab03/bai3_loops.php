<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bài 3 - Vòng lặp</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; }
        h3 { 
            color: #007bff;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }
        .section {
            margin: 30px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        table {
            border-collapse: collapse;
            margin: 20px auto;
        }
        td {
            border: 1px solid #ddd;
            padding: 10px 15px;
            text-align: center;
            min-width: 80px;
        }
        td:first-child {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }
        tr:first-child td {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }
        .form-group {
            margin: 15px 0;
        }
        input[type="number"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 200px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result-box {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            font-size: 18px;
        }
        .odd-numbers {
            display: inline-block;
            margin: 10px 5px;
            padding: 8px 12px;
            background-color: #17a2b8;
            color: white;
            border-radius: 5px;
            font-weight: bold;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Phần A: Bảng cửu chương -->
        <div class="section">
            <h3>A) Bảng cửu chương (1-9)</h3>
            <?php
            echo '<table>';
            echo '<tr><td>×</td>';
            for ($i = 1; $i <= 9; $i++) {
                echo '<td>' . $i . '</td>';
            }
            echo '</tr>';
            
            for ($i = 1; $i <= 9; $i++) {
                echo '<tr>';
                echo '<td>' . $i . '</td>';
                for ($j = 1; $j <= 9; $j++) {
                    echo '<td>' . ($i * $j) . '</td>';
                }
                echo '</tr>';
            }
            echo '</table>';
            ?>
        </div>
        
        <!-- Phần B: Tổng chữ số -->
        <div class="section">
            <h3>B) Tính tổng các chữ số </h3>
            <form method="GET" action="">
                <div class="form-group">
                    <label for="n">Nhập số n:</label>
                    <input type="number" id="n" name="n" min="0" 
                           value="<?php echo isset($_GET['n']) ? htmlspecialchars($_GET['n']) : '12345'; ?>" 
                           required>
                    <button type="submit">Tính tổng</button>
                </div>
            </form>
            
            <?php
            if (isset($_GET['n'])) {
                $n = abs((int)$_GET['n']);
                $original = $n;
                $sum = 0;
                
                // Sử dụng while để tính tổng chữ số
                while ($n > 0) {
                    $sum += $n % 10;
                    $n = (int)($n / 10);
                }
                
                echo '<div class="result-box">';
                echo 'Số ban đầu: <strong>' . number_format($original) . '</strong><br>';
                echo 'Tổng các chữ số: <strong>' . $sum . '</strong>';
                echo '</div>';
            }
            ?>
        </div>
        
        <!-- Phần C: Số lẻ -->
        <div class="section">
            <h3>C) In các số lẻ từ 1 đến N</h3>
            <form method="GET" action="">
                <div class="form-group">
                    <label for="n2">Nhập số N:</label>
                    <input type="number" id="n2" name="n2" min="1" 
                           value="<?php echo isset($_GET['n2']) ? htmlspecialchars($_GET['n2']) : '25'; ?>" 
                           required>
                    <button type="submit" name="show_odd" value="1">Hiển thị</button>
                </div>
            </form>
            
            <?php
            if (isset($_GET['n2']) && isset($_GET['show_odd'])) {
                $N = (int)$_GET['n2'];
                
                echo '<div class="result-box">';
                echo 'Các số lẻ từ 1 đến ' . $N . ' (dừng nếu vượt 15):<br><br>';
                
                for ($i = 1; $i <= $N; $i++) {
                    // Dùng continue để bỏ qua số chẵn
                    if ($i % 2 == 0) {
                        continue;
                    }
                    
                    // Dùng break để dừng sớm khi vượt 15
                    if ($i > 15) {
                        echo '<br><em>(Đã dừng vì vượt quá 15)</em>';
                        break;
                    }
                    
                    echo '<span class="odd-numbers">' . $i . '</span>';
                }
                
                echo '</div>';
            }
            ?>
        </div>

        <a href="index.php" class="back-link">← Quay lại trang chủ</a>
    </div>
</body>
</html>