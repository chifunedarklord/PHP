<?php
require_once "functions.php";

$action = $_GET["action"] ?? "home";
$a = isset($_GET["a"]) ? (float)$_GET["a"] : 0;
$b = isset($_GET["b"]) ? (float)$_GET["b"] : 0;
$n = isset($_GET["n"]) ? (int)$_GET["n"] : 0;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAB03 - Mini Utility</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        .content {
            padding: 30px;
        }
        .nav-menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .nav-link {
            display: block;
            padding: 15px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s;
            border: 2px solid transparent;
        }
        .nav-link:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        .section {
            margin: 30px 0;
        }
        .section h2 {
            color: #667eea;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
        }
        .function-menu {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .function-links {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        .func-link {
            padding: 8px 15px;
            background: white;
            color: #667eea;
            text-decoration: none;
            border-radius: 5px;
            border: 2px solid #667eea;
            transition: all 0.3s;
            font-size: 0.9em;
        }
        .func-link:hover {
            background: #667eea;
            color: white;
        }
        .result-box {
            background: #d4edda;
            border: 2px solid #28a745;
            color: #155724;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .result-box strong {
            font-size: 1.2em;
        }
        .error-box {
            background: #f8d7da;
            border: 2px solid #dc3545;
            color: #721c24;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .info-box {
            background: #d1ecf1;
            border: 2px solid #17a2b8;
            color: #0c5460;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        td, th {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #667eea;
            color: white;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>LAB03 - Mini Utility</h1>
            <p>Thực hành rẽ nhánh, vòng lặp và hàm trong PHP</p>
        </div>

        <div class="content">
            <!-- Menu điều hướng chính -->
            <div class="section">
                <h2>Danh sách bài tập</h2>
                <div class="nav-menu">
                    <a href="bai1_grade.php" class="nav-link"> Phân loại điểm</a>
                    <a href="bai2_calc.php" class="nav-link"> Máy tính mini</a>
                    <a href="bai3_loops.php" class="nav-link"> Vòng lặp</a>
                    <a href="index.php" class="nav-link">Thư viện hàm</a>
                </div>
            </div>

            <!-- Menu các hàm tiện ích -->
            <div class="section">
                <h2>Các hàm tiện ích</h2>
                
                <div class="function-menu">
                    <p><strong>Chọn chức năng để test:</strong></p>
                    <div class="function-links">
                        <a href="?action=max&a=10&b=22" class="func-link">Max(10, 22)</a>
                        <a href="?action=min&a=10&b=22" class="func-link">Min(10, 22)</a>
                        <a href="?action=prime&n=17" class="func-link"> Prime(17)</a>
                        <a href="?action=fact&n=6" class="func-link"> Factorial(6)</a>
                        <a href="?action=gcd&a=12&b=18" class="func-link"> GCD(12, 18)</a>
                    </div>
                </div>

                <?php
                // Xử lý các action
                switch ($action) {
                    case "max":
                        if (isset($_GET["a"]) && isset($_GET["b"])) {
                            $result = max2($a, $b);
                            echo '<div class="result-box">';
                            echo '<strong>Hàm: max2()</strong><br>';
                            echo 'Tìm số lớn nhất giữa hai số<br><br>';
                            echo 'max2(' . $a . ', ' . $b . ') = <strong>' . $result . '</strong>';
                            echo '</div>';
                        }
                        break;

                    case "min":
                        if (isset($_GET["a"]) && isset($_GET["b"])) {
                            $result = min2($a, $b);
                            echo '<div class="result-box">';
                            echo '<strong>Hàm: min2()</strong><br>';
                            echo 'Tìm số nhỏ nhất giữa hai số<br><br>';
                            echo 'min2(' . $a . ', ' . $b . ') = <strong>' . $result . '</strong>';
                            echo '</div>';
                        }
                        break;

                    case "prime":
                        if (isset($_GET["n"])) {
                            $result = isPrime($n);
                            $text = $result ? "LÀ số nguyên tố" : "KHÔNG phải số nguyên tố";
                            echo '<div class="result-box">';
                            echo '<strong>Hàm: isPrime()</strong><br>';
                            echo 'Kiểm tra số nguyên tố<br><br>';
                            echo 'isPrime(' . $n . ') = <strong>' . ($result ? 'true' : 'false') . '</strong><br>';
                            echo 'Số ' . $n . ' <strong>' . $text . '</strong>';
                            echo '</div>';
                        }
                        break;

                    case "fact":
                        if (isset($_GET["n"])) {
                            $result = factorial($n);
                            if ($result === null) {
                                echo '<div class="error-box">';
                                echo '<strong>Lỗi:</strong> Không thể tính giai thừa của số âm!';
                                echo '</div>';
                            } else {
                                echo '<div class="result-box">';
                                echo '<strong>Hàm: factorial()</strong><br>';
                                echo 'Tính giai thừa của số nguyên không âm<br><br>';
                                echo 'factorial(' . $n . ') = ' . $n . '! = <strong>' . number_format($result) . '</strong>';
                                echo '</div>';
                            }
                        }
                        break;

                    case "gcd":
                        if (isset($_GET["a"]) && isset($_GET["b"])) {
                            $result = gcd($a, $b);
                            echo '<div class="result-box">';
                            echo '<strong>Hàm: gcd()</strong><br>';
                            echo 'Tìm ước chung lớn nhất (ƯCLN) theo thuật toán Euclid<br><br>';
                            echo 'gcd(' . $a . ', ' . $b . ') = <strong>' . $result . '</strong>';
                            echo '</div>';
                        }
                        break;

                    case "home":
                    default:
                        echo '<div class="info-box">';
                        echo '<strong>Chào mừng đến với Lab03!</strong><br><br>';
                        echo 'Chọn một chức năng từ menu bên trên để test các hàm trong thư viện functions.php<br>';
                        echo 'Hoặc truy cập các bài tập riêng lẻ thông qua menu.';
                        echo '</div>';
                        
                        // Hiển thị danh sách các hàm có sẵn
                        echo '<h3>Các hàm trong functions.php:</h3>';
                        echo '<table>';
                        echo '<tr><th>Tên hàm</th><th>Mô tả</th><th>Ví dụ</th></tr>';
                        echo '<tr><td>max2($a, $b)</td><td>Tìm số lớn nhất</td><td>max2(10, 22) → 22</td></tr>';
                        echo '<tr><td>min2($a, $b)</td><td>Tìm số nhỏ nhất</td><td>min2(10, 22) → 10</td></tr>';
                        echo '<tr><td>isPrime($n)</td><td>Kiểm tra số nguyên tố</td><td>isPrime(17) → true</td></tr>';
                        echo '<tr><td>factorial($n)</td><td>Tính giai thừa</td><td>factorial(6) → 720</td></tr>';
                        echo '<tr><td>gcd($a, $b)</td><td>Tìm ƯCLN</td><td>gcd(12, 18) → 6</td></tr>';
                        echo '</table>';
                        break;
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>