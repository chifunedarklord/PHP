<?php
// core/Router.php - Simple query string router

class Router {
    public function dispatch() {
        // Get controller and action from query string
        $controller = isset($_GET['c']) ? $_GET['c'] : 'category';
        $action = isset($_GET['a']) ? $_GET['a'] : 'index';

        // Build controller class name
        $controllerName = ucfirst($controller) . 'Controller';
        $controllerFile = __DIR__ . '/../app/Controllers/' . $controllerName . '.php';

        // Check if controller file exists
        if (!file_exists($controllerFile)) {
            $this->show404();
            return;
        }

        // Load controller
        require_once $controllerFile;

        // Check if controller class exists
        if (!class_exists($controllerName)) {
            $this->show404();
            return;
        }

        // Instantiate controller
        $controllerObj = new $controllerName();

        // Check if action method exists
        if (!method_exists($controllerObj, $action)) {
            $this->show404();
            return;
        }

        // Call action
        $controllerObj->$action();
    }

    private function show404() {
        header("HTTP/1.0 404 Not Found");
        echo "<h1>404 - Page Not Found</h1>";
        echo "<p>The requested page does not exist.</p>";
        echo '<p><a href="index.php?c=category&a=index">Go to Categories</a></p>';
    }
}