<?php
// core/Controller.php - Base controller class

class Controller {
    protected function loadModel($modelName) {
        $modelFile = __DIR__ . '/../app/Models/' . $modelName . '.php';
        if (file_exists($modelFile)) {
            require_once $modelFile;
            return new $modelName();
        }
        die("Model $modelName not found");
    }

    protected function loadView($viewPath, $data = []) {
        extract($data);
        $viewFile = __DIR__ . '/../app/Views/' . $viewPath . '.php';
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            die("View $viewPath not found");
        }
    }

    protected function redirect($url) {
        header("Location: $url");
        exit;
    }

    protected function setFlash($type, $message) {
        $_SESSION['flash_type'] = $type;
        $_SESSION['flash_message'] = $message;
    }

    protected function getFlash() {
        if (isset($_SESSION['flash_message'])) {
            $flash = [
                'type' => $_SESSION['flash_type'],
                'message' => $_SESSION['flash_message']
            ];
            unset($_SESSION['flash_type']);
            unset($_SESSION['flash_message']);
            return $flash;
        }
        return null;
    }
}