<?php
// app/Models/Category.php - Category model

class Category {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function getAll($search = '') {
        try {
            if (!empty($search)) {
                $sql = "SELECT * FROM categories WHERE name LIKE :search ORDER BY id DESC";
                $stmt = $this->db->prepare($sql);
                $stmt->execute(['search' => '%' . $search . '%']);
            } else {
                $sql = "SELECT * FROM categories ORDER BY id DESC";
                $stmt = $this->db->prepare($sql);
                $stmt->execute();
            }
            return $stmt->fetchAll();
        } catch(PDOException $e) {
            return [];
        }
    }

    public function findById($id) {
        try {
            $sql = "SELECT * FROM categories WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id' => $id]);
            return $stmt->fetch();
        } catch(PDOException $e) {
            return null;
        }
    }

    public function insert($data) {
        try {
            $sql = "INSERT INTO categories (name, status) VALUES (:name, :status)";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                'name' => $data['name'],
                'status' => $data['status']
            ]);
        } catch(PDOException $e) {
            return false;
        }
    }

    public function update($id, $data) {
        try {
            $sql = "UPDATE categories SET name = :name, status = :status WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                'id' => $id,
                'name' => $data['name'],
                'status' => $data['status']
            ]);
        } catch(PDOException $e) {
            return false;
        }
    }

    public function delete($id) {
        try {
            $sql = "DELETE FROM categories WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute(['id' => $id]);
        } catch(PDOException $e) {
            return false;
        }
    }

    public function existsByName($name, $excludeId = null) {
        try {
            if ($excludeId) {
                $sql = "SELECT COUNT(*) FROM categories WHERE name = :name AND id != :id";
                $stmt = $this->db->prepare($sql);
                $stmt->execute(['name' => $name, 'id' => $excludeId]);
            } else {
                $sql = "SELECT COUNT(*) FROM categories WHERE name = :name";
                $stmt = $this->db->prepare($sql);
                $stmt->execute(['name' => $name]);
            }
            return $stmt->fetchColumn() > 0;
        } catch(PDOException $e) {
            return false;
        }
    }
}