<?php
// app/Controllers/CategoryController.php - Category controller

class CategoryController extends Controller {
    private $categoryModel;

    public function __construct() {
        $this->categoryModel = $this->loadModel('Category');
    }

    public function index() {
        $search = isset($_GET['q']) ? trim($_GET['q']) : '';
        $categories = $this->categoryModel->getAll($search);
        
        $this->loadView('categories/index', [
            'categories' => $categories,
            'search' => $search,
            'flash' => $this->getFlash()
        ]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $errors = $this->validateCategory($_POST);
            
            if (empty($errors)) {
                $data = [
                    'name' => trim($_POST['name']),
                    'status' => isset($_POST['status']) ? 1 : 0
                ];
                
                if ($this->categoryModel->insert($data)) {
                    $this->setFlash('success', 'Category created successfully!');
                    $this->redirect('index.php?c=category&a=index');
                } else {
                    $errors[] = 'Failed to create category. Please try again.';
                }
            }
            
            $this->loadView('categories/create', [
                'errors' => $errors,
                'old' => $_POST
            ]);
        } else {
            $this->loadView('categories/create', [
                'errors' => [],
                'old' => []
            ]);
        }
    }

    public function edit() {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $category = $this->categoryModel->findById($id);
        
        if (!$category) {
            $this->setFlash('error', 'Category not found!');
            $this->redirect('index.php?c=category&a=index');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $errors = $this->validateCategory($_POST, $id);
            
            if (empty($errors)) {
                $data = [
                    'name' => trim($_POST['name']),
                    'status' => isset($_POST['status']) ? 1 : 0
                ];
                
                if ($this->categoryModel->update($id, $data)) {
                    $this->setFlash('success', 'Category updated successfully!');
                    $this->redirect('index.php?c=category&a=index');
                } else {
                    $errors[] = 'Failed to update category. Please try again.';
                }
            }
            
            $this->loadView('categories/edit', [
                'category' => $category,
                'errors' => $errors,
                'old' => $_POST
            ]);
        } else {
            $this->loadView('categories/edit', [
                'category' => $category,
                'errors' => [],
                'old' => $category
            ]);
        }
    }

    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            
            if ($this->categoryModel->delete($id)) {
                $this->setFlash('success', 'Category deleted successfully!');
            } else {
                $this->setFlash('error', 'Failed to delete category!');
            }
        }
        
        $this->redirect('index.php?c=category&a=index');
    }

    private function validateCategory($data, $excludeId = null) {
        $errors = [];
        
        // Validate name
        if (empty($data['name']) || trim($data['name']) === '') {
            $errors[] = 'Category name is required.';
        } elseif (strlen(trim($data['name'])) < 2) {
            $errors[] = 'Category name must be at least 2 characters.';
        } elseif (strlen(trim($data['name'])) > 100) {
            $errors[] = 'Category name must not exceed 100 characters.';
        } elseif ($this->categoryModel->existsByName(trim($data['name']), $excludeId)) {
            $errors[] = 'Category name already exists.';
        }
        
        return $errors;
    }
}