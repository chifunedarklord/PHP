-- database.sql - Create database and tables

-- Create database
CREATE DATABASE IF NOT EXISTS mvc_crud_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE mvc_crud_db;

-- Drop table if exists
DROP TABLE IF EXISTS categories;

-- Create categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    status TINYINT DEFAULT 1 COMMENT '1 = Active, 0 = Inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data
INSERT INTO categories (name, status) VALUES
('Kitchen Tools', 1),
('Appliances', 1),
('Health & Care', 1),
('Electronics', 1),
('Home Decor', 0),
('Furniture', 1),
('Sports & Outdoors', 1);