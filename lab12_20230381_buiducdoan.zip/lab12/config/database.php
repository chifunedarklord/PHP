<?php
// config/database.php - Database configuration

define('DB_HOST', 'localhost');
define('DB_NAME', 'mvc_crud_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');