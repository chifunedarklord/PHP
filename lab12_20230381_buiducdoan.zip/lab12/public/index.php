<?php
// public/index.php - Entry point of the application

session_start();

// Load configuration
require_once __DIR__ . '/../config/database.php';

// Load core classes
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Router.php';

// Initialize router
$router = new Router();
$router->dispatch();