MVC CRUD Project - Category Management
Dự án quản lý danh mục sản phẩm sử dụng mô hình MVC thuần PHP với PDO.
Yêu cầu hệ thống

PHP 7.4 trở lên
MySQL 5.7 trở lên / MariaDB
Web server (Apache/Nginx) hoặc PHP built-in server

Cấu trúc thư mục
mvc-crud/
├── public/
│   └── index.php              # Entry point
├── core/
│   ├── Router.php             # Router xử lý điều hướng
│   ├── Controller.php         # Base controller
│   └── Database.php           # Database connection
├── app/
│   ├── Controllers/
│   │   └── CategoryController.php
│   ├── Models/
│   │   └── Category.php
│   └── Views/
│       └── categories/
│           ├── index.php      # Danh sách + tìm kiếm
│           ├── create.php     # Thêm mới
│           └── edit.php       # Chỉnh sửa
├── config/
│   └── database.php           # Cấu hình database
├── database.sql               # Database schema + data mẫu
└── README.md
Hướng dẫn cài đặt
Bước 1: Import Database

Mở phpMyAdmin hoặc MySQL client
Tạo database mới hoặc import file database.sql:

bashmysql -u root -p < database.sql
Hoặc chạy trực tiếp trong MySQL:
sqlsource /path/to/database.sql
Bước 2: Cấu hình kết nối Database
Mở file config/database.php và điều chỉnh thông tin kết nối:
phpdefine('DB_HOST', 'localhost');
define('DB_NAME', 'mvc_crud_db');
define('DB_USER', 'root');        // Thay đổi username
define('DB_PASS', '');            // Thay đổi password
define('DB_CHARSET', 'utf8mb4');
Bước 3: Chạy ứng dụng
Sử dụng PHP Built-in Server (khuyến nghị cho dev):
bashcd mvc-crud/public
php -S localhost:8000
Truy cập: http://localhost:8000/index.php?c=category&a=index
Sử dụng Apache/Nginx:

Copy thư mục mvc-crud vào htdocs (XAMPP) hoặc www (WAMP)
Truy cập: http://localhost/mvc-crud/public/index.php?c=category&a=index

Các URL quan trọng
Chức năngURLDanh sách danh mụcindex.php?c=category&a=indexTìm kiếmindex.php?c=category&a=index&q=keywordThêm mớiindex.php?c=category&a=createChỉnh sửaindex.php?c=category&a=edit&id=1Xóaindex.php?c=category&a=delete (POST)
Tính năng
✅ CRUD đầy đủ: Create, Read, Update, Delete
✅ Tìm kiếm: Tìm theo tên danh mục
✅ Validation: Kiểm tra dữ liệu đầu vào
✅ Bảo mật: PDO Prepared Statements, htmlspecialchars()
✅ Flash Message: Thông báo thành công/lỗi
✅ Router: Điều hướng qua query string
Validation Rules

Tên danh mục:

Không được để trống
Tối thiểu 2 ký tự
Tối đa 100 ký tự
Không được trùng tên (unique)



Bảo mật

SQL Injection: Sử dụng PDO Prepared Statements
XSS: Escape output bằng htmlspecialchars()
CSRF: Có thể mở rộng thêm CSRF token
Validation: Kiểm tra dữ liệu đầu vào ở cả client và server

Mở rộng
Có thể mở rộng thêm các tính năng:

Phân trang (pagination)
Lọc theo trạng thái (Active/Inactive)
Export CSV/Excel
Upload ảnh cho danh mục
Soft delete
Logs hoạt động

Troubleshooting
Lỗi kết nối database:

Kiểm tra thông tin trong config/database.php
Đảm bảo MySQL đang chạy
Kiểm tra username/password

Lỗi 404:

Đảm bảo đang truy cập từ thư mục public/
Kiểm tra đường dẫn controller và action

Lỗi PDO:

Kiểm tra PDO extension đã được bật trong php.ini
Đảm bảo database đã được tạo và có dữ liệu

Tác giả
Dự án MVC CRUD - Quản lý danh mục sản phẩm
License
MIT License - Free to use for educational purposes