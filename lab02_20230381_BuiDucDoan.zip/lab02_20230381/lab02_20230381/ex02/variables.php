<?php

// Khai báo biến
$fullName = "Bùi Đức Đoàn";
$age = 20;
$gpa = 3.75;
$isActive = true;

// Khai báo hằng
const SCHOOL = "Đại học Công nghệ Đông Á";

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biến và Hằng</title>
    <style>
        body {
            font-family: 'Courier New', monospace;
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h2 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .section {
            margin: 20px 0;
            padding: 15px;
            background: #ecf0f1;
            border-radius: 5px;
        }
        pre {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">        
        <div class="section">
            <p><strong>Họ tên:</strong> <?php echo $fullName; ?></p>
            <p><strong>Tuổi:</strong> <?php echo $age; ?></p>
            <p><strong>Điểm GPA:</strong> <?php echo $gpa; ?></p>
            <p><strong>Trạng thái:</strong> <?php echo $isActive ? 'Đang hoạt động' : 'Không hoạt động'; ?></p>
            <p><strong>Trường:</strong> <?php echo SCHOOL; ?></p>
        </div>

        <div class="section">
            <h2>Debug bằng var_dump()</h2>
            <p><strong>$fullName:</strong></p>
            <pre><?php var_dump($fullName); ?></pre>
            
            <p><strong>$age:</strong></p>
            <pre><?php var_dump($age); ?></pre>
            
            <p><strong>$gpa:</strong></p>
            <pre><?php var_dump($gpa); ?></pre>
            
            <p><strong>$isActive:</strong></p>
            <pre><?php var_dump($isActive); ?></pre>
            
            <p><strong>SCHOOL:</strong></p>
            <pre><?php var_dump(SCHOOL); ?></pre>
        </div>

        <div class="section">
            <h2>String Interpolation</h2>
            
            <p><strong>double quotes:</strong></p>
            <p><?php echo "Tuoi: $age"; ?></p>
            <p><?php echo "Ten: $fullName, GPA: $gpa"; ?></p>
            
            <p><strong>single quotes:</strong></p>
            <p><?php echo 'Tuoi: $age'; ?></p>
            <p><?php echo 'Ten: $fullName, GPA: $gpa'; ?></p>
            
            <p><strong>Nhận xét:</strong></p>
            <ul>
                <li><em>Nháy kép (""):</em> PHP sẽ thay thế biến bằng giá trị của nó</li>
                <li><em>Nháy đơn (''):</em> PHP không xử lý biến, in ra đúng như văn bản gốc</li>
            </ul>
            
            <?php
              // Nhận xét trong code:
            // - Nháy kép: biến $age được thay thế bằng giá trị 20
            // - Nháy đơn: chuỗi '$age' được in ra nguyên văn, không xử lý biến
            ?>
        </div>
    </div>
</body>
</html>