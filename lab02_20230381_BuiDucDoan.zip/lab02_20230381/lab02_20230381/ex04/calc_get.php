<?php
$result = null;
$error = null;
$calculation = null;

// Kiểm tra có đủ tham số không
if (isset($_GET['a']) && isset($_GET['b']) && isset($_GET['op'])) {
    // Ép kiểu sang số
    $a = floatval($_GET['a']);
    $b = floatval($_GET['b']);
    $op = $_GET['op'];
    
    // Xử lý phép tính
    switch($op) {
        case 'add':
            $result = $a + $b;
            $calculation = "$a + $b = $result";
            break;
        case 'sub':
            $result = $a - $b;
            $calculation = "$a - $b = $result";
            break;
        case 'mul':
            $result = $a * $b;
            $calculation = "$a × $b = $result";
            break;
        case 'div':
            if ($b == 0) {
                $error = "Không thể chia cho 0";
            } else {
                $result = $a / $b;
                $calculation = "$a ÷ $b = $result";
            }
            break;
        default:
            $error = "Phép tính không hợp lệ. Chỉ chấp nhận: add, sub, mul, div";
    }
} else {
    // Thiếu tham số
    $error = "Thiếu tham số!";
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Máy tính GET</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
        }
        .result-box {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            margin: 20px 0;
        }
        .error-box {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            padding: 20px;
            border-radius: 10px;
            color: #721c24;
            font-weight: bold;
            margin: 20px 0;
        }
        .instructions {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #3498db;
        }
        .instructions h3 {
            color: #3498db;
            margin-top: 0;
        }
        .url-example {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 10px 15px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            margin: 8px 0;
            overflow-x: auto;
            white-space: nowrap;
        }
        .url-example:hover {
            background: #34495e;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧮 Máy tính với GET</h1>
        
        <?php if ($error): ?>
            <div class="error-box">
                ⚠️ Lỗi: <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($calculation): ?>
            <div class="result-box">
                ✅ <?php echo $calculation; ?>
            </div>
        <?php endif; ?>
        
        <div class="instructions">
            <h3>📝 Hướng dẫn sử dụng:</h3>
            <p>Truy cập URL theo cú pháp: <code>calc_get.php?a=[số1]&b=[số2]&op=[phép tính]</code></p>
            
            <p><strong>Các phép tính (op):</strong></p>
            <ul>
                <li><code>add</code> - Cộng</li>
                <li><code>sub</code> - Trừ</li>
                <li><code>mul</code> - Nhân</li>
                <li><code>div</code> - Chia</li>
            </ul>
            
            <h4>Ví dụ URL:</h4>
            <div class="url-example">
                ?a=10&b=3&op=add
            </div>
            <div class="url-example">
                ?a=15&b=5&op=sub
            </div>
            <div class="url-example">
                ?a=7&b=8&op=mul
            </div>
            <div class="url-example">
                ?a=20&b=4&op=div
            </div>
            <div class="url-example">
                ?a=10&b=0&op=div (sẽ báo lỗi)
            </div>
        </div>
    </div>
</body>
</html>