<?php
$a = 10;
$b = 3;

// Tính toán các phép tính
$sum = $a + $b;
$diff = $a - $b;
$product = $a * $b;
$quotient = $a / $b;
$remainder = $a % $b;

// Sử dụng toán tử nối chuỗi (.)
$message = "Kết quả tính toán với a = " . $a . " và b = " . $b;
$message .= " được thực hiện thành công!";

// So sánh == và ===
$compare1 = "5" == 5;   // So sánh giá trị (không quan tâm kiểu)
$compare2 = "5" === 5;  // So sánh giá trị VÀ kiểu dữ liệu

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toán tử cơ bản</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: #f0f4f8;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
        }
        h2 {
            color: #3498db;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 8px;
        }
        .result {
            background: #ecf0f1;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            font-size: 18px;
        }
        .result strong {
            color: #e74c3c;
        }
        .info {
            background: #d5f4e6;
            border-left: 4px solid #27ae60;
            padding: 15px;
            margin: 15px 0;
        }
        .comparison {
            background: #fef5e7;
            border-left: 4px solid #f39c12;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="info">
            <p><?php echo $message; ?></p>
        </div>

        <h2>Các phép tính số học</h2>
        
        <div class="result">
            Tổng: <?php echo $a; ?> + <?php echo $b; ?> = <strong><?php echo $sum; ?></strong>
        </div>
        
        <div class="result">
            Hiệu: <?php echo $a; ?> - <?php echo $b; ?> = <strong><?php echo $diff; ?></strong>
        </div>
        
        <div class="result">
            Tích: <?php echo $a; ?> × <?php echo $b; ?> = <strong><?php echo $product; ?></strong>
        </div>
        
        <div class="result">
            Thương: <?php echo $a; ?> ÷ <?php echo $b; ?> = <strong><?php echo round($quotient, 2); ?></strong>
        </div>
        
        <div class="result">
            Chia lấy dư: <?php echo $a; ?> % <?php echo $b; ?> = <strong><?php echo $remainder; ?></strong>
        </div>

        <h2>So sánh == và ===</h2>
        
        <div class="comparison">
            <p><strong>"5" == 5:</strong> <?php echo $compare1 ? 'true' : 'false'; ?> (kết quả: true)</p>
            <p><strong>"5" === 5:</strong> <?php echo $compare2 ? 'true' : 'false'; ?> (kết quả: false)</p>
            
            <hr>
            
            <p><em>Giải thích:</em></p>
            <ul>
                <li><strong>== (So sánh lỏng lẻo):</strong> Chỉ so sánh giá trị, không quan tâm kiểu dữ liệu. 
                    PHP tự động chuyển đổi "5" (string) thành 5 (integer) trước khi so sánh, nên kết quả là true.</li>
                <li><strong>=== (So sánh nghiêm ngặt):</strong> So sánh cả giá trị VÀ kiểu dữ liệu. 
                    "5" là string còn 5 là integer, hai kiểu khác nhau nên kết quả là false.</li>
            </ul>
        </div>

        <?php
        /* 
         * Nhận xét về toán tử nối chuỗi:
         * - Toán tử . (dấu chấm) dùng để nối các chuỗi lại với nhau
         * - Toán tử .= dùng để nối thêm chuỗi vào cuối chuỗi hiện có
         * - Ví dụ: $message .= " thêm text" tương đương $message = $message . " thêm text"
         */
        ?>
    </div>
</body>
</html>