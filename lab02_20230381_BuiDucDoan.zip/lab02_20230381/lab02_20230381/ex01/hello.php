<?php
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
        }
        .info {
            line-height: 1.8;
            color: #34495e;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Hello PHP!</h1>
        <div class="info">
            <p><strong>Họ tên:</strong> Bùi Đức Đoàn</p>
            <p><strong>MSSV:</strong> 20230381</p>
            <p><strong>Lớp:</strong> IT14.1</p>
            <p><strong>Ngày giờ hiện tại:</strong> <?php echo date('d/m/Y H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>