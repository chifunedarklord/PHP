<?php
// Bài 5 - Form GET: Tính BMI và phân loại

$bmi = null;
$category = null;
$error = null;
$name = '';
$height = '';
$weight = '';

// Kiểm tra nếu form đã được submit
if (isset($_GET['submit'])) {
    // Lấy dữ liệu từ GET
    $name = $_GET['name'] ?? '';
    $height = $_GET['height'] ?? '';
    $weight = $_GET['weight'] ?? '';
    
    // Validate dữ liệu
    if (empty($name)) {
        $error = "Vui lòng nhập họ tên!";
    } elseif (empty($height) || empty($weight)) {
        $error = "Vui lòng nhập đầy đủ chiều cao và cân nặng!";
    } elseif (!is_numeric($height) || !is_numeric($weight)) {
        $error = "Chiều cao và cân nặng phải là số!";
    } elseif ($height <= 0 || $weight <= 0) {
        $error = "Chiều cao và cân nặng phải lớn hơn 0!";
    } else {
        // Ép kiểu và tính BMI
        $height = floatval($height);
        $weight = floatval($weight);
        
        // Tính BMI
        $bmi = $weight / ($height * $height);
        $bmi = round($bmi, 2);
        
        // Phân loại BMI
        if ($bmi < 18.5) {
            $category = "Gầy";
            $categoryColor = "#3498db";
        } elseif ($bmi >= 18.5 && $bmi <= 24.9) {
            $category = "Bình thường";
            $categoryColor = "#27ae60";
        } elseif ($bmi >= 25 && $bmi <= 29.9) {
            $category = "Thừa cân";
            $categoryColor = "#f39c12";
        } else {
            $category = "Béo phì";
            $categoryColor = "#e74c3c";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tính chỉ số BMI</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: white;
            max-width: 600px;
            width: 100%;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            text-align: center;
            color: #7f8c8d;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ecf0f1;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }
        input[type="text"]:focus,
        input[type="number"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .input-hint {
            font-size: 12px;
            color: #95a5a6;
            margin-top: 5px;
        }
        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 10px;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        button:active {
            transform: translateY(0);
        }
        .result-box {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            padding: 30px;
            border-radius: 15px;
            margin-top: 30px;
            text-align: center;
            animation: slideIn 0.5s ease-out;
        }
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .result-box h2 {
            color: white;
            margin-bottom: 20px;
            font-size: 24px;
        }
        .bmi-value {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin: 15px 0;
        }
        .bmi-number {
            font-size: 48px;
            font-weight: bold;
            color: #2c3e50;
        }
        .bmi-category {
            font-size: 24px;
            font-weight: bold;
            padding: 15px;
            border-radius: 10px;
            color: white;
            margin-top: 15px;
        }
        .result-name {
            color: white;
            font-size: 18px;
            margin-bottom: 15px;
        }
        .error-box {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            color: #721c24;
            font-weight: bold;
            text-align: center;
            animation: shake 0.5s;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }
        .bmi-guide {
            background: #ecf0f1;
            padding: 20px;
            border-radius: 10px;
            margin-top: 30px;
        }
        .bmi-guide h3 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .bmi-guide ul {
            list-style: none;
        }
        .bmi-guide li {
            padding: 8px 0;
            border-bottom: 1px solid #bdc3c7;
        }
        .bmi-guide li:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚕️ Tính chỉ số BMI</h1>
        <p class="subtitle">Body Mass Index Calculator</p>
        
        <form method="GET" action="">
            <div class="form-group">
                <label for="name">👤 Họ và tên:</label>
                <input type="text" id="name" name="name" 
                       value="<?php echo htmlspecialchars($name); ?>" 
                       placeholder="Nhập họ tên của bạn">
            </div>
            
            <div class="form-group">
                <label for="height">📏 Chiều cao (m):</label>
                <input type="number" id="height" name="height" 
                       step="0.01" min="0" 
                       value="<?php echo htmlspecialchars($height); ?>"
                       placeholder="Ví dụ: 1.70">
                <div class="input-hint">Đơn vị: mét (m)</div>
            </div>
            
            <div class="form-group">
                <label for="weight">⚖️ Cân nặng (kg):</label>
                <input type="number" id="weight" name="weight" 
                       step="0.1" min="0" 
                       value="<?php echo htmlspecialchars($weight); ?>"
                       placeholder="Ví dụ: 65">
                <div class="input-hint">Đơn vị: kilogram (kg)</div>
            </div>
            
            <button type="submit" name="submit">🧮 Tính BMI</button>
        </form>
        
        <?php if ($error): ?>
            <div class="error-box">
                ⚠️ <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($bmi !== null && !$error): ?>
            <div class="result-box">
                <h2>📊 Kết quả của bạn</h2>
                <div class="result-name">
                    <strong><?php echo htmlspecialchars($name); ?></strong>
                </div>
                <div class="bmi-value">
                    <div style="color: #7f8c8d; font-size: 14px; margin-bottom: 5px;">
                        Chỉ số BMI
                    </div>
                    <div class="bmi-number">
                        <?php echo $bmi; ?>
                    </div>
                </div>
                <div class="bmi-category" style="background-color: <?php echo $categoryColor; ?>;">
                    <?php echo $category; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="bmi-guide">
            <h3>📋 Bảng phân loại BMI</h3>
            <ul>
                <li><strong>BMI &lt; 18.5:</strong> Gầy (Thiếu cân)</li>
                <li><strong>BMI 18.5 - 24.9:</strong> Bình thường (Lý tưởng)</li>
                <li><strong>BMI 25.0 - 29.9:</strong> Thừa cân</li>
                <li><strong>BMI ≥ 30.0:</strong> Béo phì</li>
            </ul>
        </div>
    </div>
</body>
</html>